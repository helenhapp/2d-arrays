// ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦
// 📝 ЗАВДАННЯ 1.1: Квітка (3x3)
// ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦

const flowerPalette = {
  0: "transparent", // 0 - прозорий
  1: "#facc15", // 1 - жовтий (центр)
  2: "#d946ef", // 2 - рожевий (пелюстки)
};

/* 🔸 1. допиши масив flower 🔸 */
let flower;


// ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦
// 📝 ЗАВДАННЯ 1.2: Пейзаж (5x5)
// ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦

const landscapePalette = {
  0: "#60a5fa", // 0 - блакитний (небо)
  1: "#facc15", // 1 - жовтий (сонце)
  2: "#166534", // 2 - темно-зелений (листя)
  3: "#78350f", // 3 - коричневий (стовбур)
  4: "#6bdf69", // 4 - світло-зелений (трава)
};

/* 🔸 2. допиши масив landscape 🔸 */
let landscape;


// ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦
// 📝 ЗАВДАННЯ 1.3: Сердечко (6 x 7: 6 рядків, 7 колонок)
// ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦

const heartPalette = {
  0: "transparent", // 0 - прозорий
  1: "#ef4444", // 1 - червоний
};

/* 🔸 3. допиши масив heart 🔸 */
let heart;


// ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦ - ✦
// Об'єкт малюється, якщо заповнений відповідний масив
if (flower && flower.length > 0) drawPixelArt(flower, "Квітка", flowerPalette);
if (landscape && landscape.length > 0) drawPixelArt(landscape, "Пейзаж", landscapePalette);
if (heart && heart.length > 0) drawPixelArt(heart, "HP", heartPalette);
